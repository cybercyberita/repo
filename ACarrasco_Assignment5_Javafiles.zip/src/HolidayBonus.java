
public class HolidayBonus {

    private static double LOW_BONUS = 1000;
    private static double MID_BONUS = 2000;
    private static double MAX_BONUS = 5000;
    public static double[] calculateHolidayBonus(double[][] data)
    {
        double[] bonuses = new double[data.length];

        int rowIndex = 0;
        for(double[] row : data)
        {
            for(int col = 0 ; col < row.length ; col ++)  
            {   // search each column to see if the current row holds the highest or lowest profit
                int highestStoreIndex = TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, col);
                int lowestStoreIndex = TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, col);
                
                if(highestStoreIndex == rowIndex)
                    bonuses[rowIndex] += MAX_BONUS;
                else if (lowestStoreIndex == rowIndex)
                    bonuses[rowIndex] += LOW_BONUS;
                else
                    bonuses[rowIndex] += MID_BONUS;
            }
            rowIndex++;
        }
        return bonuses;
    }
    public static double calculateTotalHolidayBonus(double[][] data)
    {
        double[] bonuses = calculateHolidayBonus(data);
        int total = 0;
        for(double d : bonuses)
            total += d;
        return total;
    }
}
