/*
 * Class: CMSC203 22502
 * Instructor: David Kuijt
 * Description: A data structure to hold different sized arrays (ragged array)
 * Due: 11/17/2024
 * Platform/compiler: VS Code
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Adrian Carrasco
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility 
{
    public static double[][] readFile(File file) throws FileNotFoundException 
    {
        Scanner scanner = new Scanner(file);
        ArrayList<double[]> tempList = new ArrayList<>();
        
        while (scanner.hasNextLine()) {
            String[] line = scanner.nextLine().split(" ");
            double[] values = new double[line.length];

            for(int i = 0 ; i < line.length; i++)
                values[i] = Double.parseDouble(line[i]);
            
            tempList.add(values);
        }
        
        scanner.close();
        return tempList.toArray(new double[tempList.size()][]);
    }

    public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException 
    {
        PrintWriter writer = new PrintWriter(outputFile);

        for (double[] row : data) {
            for (double value : row) 
                writer.print(value + " ");
            writer.println();
        }

        writer.close();
    }

    public static double getTotal(double[][] data) 
    {
        double total = 0.0;
        for (double[] row : data) {
            for (double value : row) 
                total += value;
        }
        return total;
    }

    public static double getAverage(double[][] data) {
        double total = getTotal(data);
        int count = 0;
        for (double[] row : data) {
            count += row.length;
        }
        return total / count;
    }

    public static double getRowTotal(double[][] data, int row) {
        double total = 0;
        for(Double colData : data[row])
            total += colData;
        return total;
    }

    public static double getColumnTotal(double[][] data, int col) 
    {
        int total = 0;
        for (double[] array : data) 
        {
            try {
                total += array[col];
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Index out of bounds. Skipping.");
            }
        }
        return total;
    }

    public static double getHighestInRow(double[][] data, int row) {
        double highest = Double.NEGATIVE_INFINITY;
        for(Double colData : data[row])
            if(colData > highest) highest = colData;
        return highest;
    }

    public static int getHighestInRowIndex(double[][] data, int row) {
        double max = getHighestInRow(data, row);
        for (int i = 0; i < data[row].length; i++) {
            if (data[row][i] == max) return i;
        }
        return -1;
        
    }

    public static double getLowestInRow(double[][] data, int row) {
        double lowest = Double.POSITIVE_INFINITY;
        for(Double colData : data[row])
            if(colData < lowest ) lowest = colData;
        return lowest;
    }

    public static int getLowestInRowIndex(double[][] data, int row) {
        double min = getLowestInRow(data, row);
        for (int i = 0; i < data[row].length; i++) {
            if (data[row][i] == min) return i;
        }
        return -1;
    }

    public static double getHighestInColumn(double[][] data, int col) {
        double highest = Double.NEGATIVE_INFINITY;
        for (double[] row : data) {
            try {
                if(row[col] > highest) highest = row[col];
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Index out of bounds for current row. Skipping.");
            }
        }
        return highest;
    }
    
    public static int getHighestInColumnIndex(double[][] data, int col) {
        double highest = getHighestInColumn(data, col);
        for (int i = 0; i < data.length; i++) {
            try {
                if (data[i][col] == highest) return i;
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Index out of bounds for row " + i + ". Skipping.");
            }
        }
        return -1;
    }
    
    public static double getLowestInColumn(double[][] data, int col) {
        double lowest = Double.POSITIVE_INFINITY;
        for (double[] row : data) {
            try {
                if(row[col] < lowest) lowest = row[col];
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Index out of bounds for current row. Skipping.");
            }
        }
        return lowest;
    }
    
    public static int getLowestInColumnIndex(double[][] data, int col) {
        double min = getLowestInColumn(data, col);
        for (int i = 0; i < data.length; i++) {
            try {
                if (data[i][col] == min) return i;
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Index out of bounds for row " + i + ". Skipping.");
            }
        }
        return -1;
    }

    public static double getHighestInArray(double[][] data) {
        double highest = Double.NEGATIVE_INFINITY;
        for(int i = 0 ; i < data.length; i++)
        {
            if(getHighestInRow(data, i) > highest) highest = getHighestInRow(data, i);
        }
        return highest;
    }

    public static double getLowestInArray(double[][] data) {
        double lowest = Double.POSITIVE_INFINITY;
        for(int i = 0 ; i < data.length; i++)
        {
            if(getLowestInRow(data, i) < lowest) lowest = getLowestInRow(data, i);
        }
        return lowest;
    }
}