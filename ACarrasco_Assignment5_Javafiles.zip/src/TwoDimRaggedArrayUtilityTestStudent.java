import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class TwoDimRaggedArrayUtilityTestStudent {

    private double[][] data;
    private String srcFolder = "C:\\Users\\adria\\OneDrive\\Desktop\\CMSC 203\\holidayPay";

    @BeforeEach
    void setUp() {
        data = new double[][] {
            {1.0, 2.0, 3.0},
            {4.0, 5.0},
            {6.0, 7.0, 8.0}
        };

    }

    @Test
    void testGetAverage() {
        double average = TwoDimRaggedArrayUtility.getAverage(data);
        assertEquals(4.5, average, 0.001);
    }

    @Test
    void testGetColumnTotal() {
        double columnTotal = TwoDimRaggedArrayUtility.getColumnTotal(data, 1);
        assertEquals(14.0, columnTotal, 0.001);
    }

    @Test
    void testGetHighestInArray() {
        double highest = TwoDimRaggedArrayUtility.getHighestInArray(data);
        assertEquals(8.0, highest, 0.001);
    }

    @Test
    void testGetHighestInColumn() {
        double highest = TwoDimRaggedArrayUtility.getHighestInColumn(data, 1);
        assertEquals(7.0, highest, 0.001);
    }

    @Test
    void testGetHighestInColumnIndex() {
        int index = TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, 1);
        assertEquals(2, index);
    }

    @Test
    void testGetHighestInRow() {
        double highest = TwoDimRaggedArrayUtility.getHighestInRow(data, 2);
        assertEquals(8.0, highest, 0.001);
    }

    @Test
    void testGetHighestInRowIndex() {
        int index = TwoDimRaggedArrayUtility.getHighestInRowIndex(data, 2);
        assertEquals(2, index);
    }

    @Test
    void testGetLowestInArray() {
        double lowest = TwoDimRaggedArrayUtility.getLowestInArray(data);
        assertEquals(1.0, lowest, 0.001);
    }

    @Test
    void testGetLowestInColumn() {
        double lowest = TwoDimRaggedArrayUtility.getLowestInColumn(data, 1);
        assertEquals(2.0, lowest, 0.001);
    }

    @Test
    void testGetLowestInColumnIndex() {
        int index = TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, 1);
        assertEquals(0, index);
    }

    @Test
    void testGetLowestInRow() {
        double lowest = TwoDimRaggedArrayUtility.getLowestInRow(data, 2);
        assertEquals(6.0, lowest, 0.001);
    }

    @Test
    void testGetLowestInRowIndex() {
        int index = TwoDimRaggedArrayUtility.getLowestInRowIndex(data, 2);
        assertEquals(0, index);
    }

    @Test
    void testGetRowTotal() {
        double rowTotal = TwoDimRaggedArrayUtility.getRowTotal(data, 1);
        assertEquals(9.0, rowTotal, 0.001);
    }

    @Test
    void testGetTotal() {
        double total = TwoDimRaggedArrayUtility.getTotal(data);
        assertEquals(36.0, total, 0.001);
    }

    @Test
    void testReadFile() 
    {
        double[][] result;
        try {
            result = TwoDimRaggedArrayUtility.readFile(new File(srcFolder + "\\dataSet1.txt"));
        } catch (FileNotFoundException e) {
            result = null;
            fail("This should not have caused an Exception");

        }

        // Assert
        assertNotNull(result);
        assertEquals(3, result.length); // Three rows
        assertArrayEquals(new double[]{1.0, 2.0, 3.0}, result[0]);
        assertArrayEquals(new double[]{4.0, 5.0}, result[1]);
        assertArrayEquals(new double[]{6.0, 7.0, 8.0}, result[2]);
    }

    @Test
    void testWriteToFile() {
        // Arrange
        File tempFile = new File("./test.txt");
        try (FileWriter writer = new FileWriter(tempFile)) {
            writer.write("1.0 2.0 3.0\n");
            writer.write("4.0 5.0\n");
            writer.write("6.0 7.0 8.0\n");
        } catch (IOException e) {
            fail("This should not have caused an Exception");
        }

        // Act
        double[][] result;
        try {
            result = TwoDimRaggedArrayUtility.readFile(tempFile);
        } catch (FileNotFoundException e) {
            result = null;
            fail("This should not have caused an Exception");
        }

        // Assert
        assertNotNull(result);
        assertEquals(3, result.length); // Three rows
        assertArrayEquals(new double[]{1.0, 2.0, 3.0}, result[0]);
        assertArrayEquals(new double[]{4.0, 5.0}, result[1]);
        assertArrayEquals(new double[]{6.0, 7.0, 8.0}, result[2]);
    }
}
