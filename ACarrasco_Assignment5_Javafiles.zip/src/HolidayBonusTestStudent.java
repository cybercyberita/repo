import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class HolidayBonusTestStudent 
{
    private double[][] dataset1;
    private double[][] dataset2;
    private double[][] dataset3;

    @BeforeEach
	public void setUp() throws Exception {
        dataset1 = TwoDimRaggedArrayUtility.readFile(new File("district3.txt"));
        dataset2 = TwoDimRaggedArrayUtility.readFile(new File("district4.txt"));
        dataset3 = TwoDimRaggedArrayUtility.readFile(new File("district5.txt"));
	}

	@After
	public void tearDown() throws Exception {

	}

    @Test
    void testCalculateHolidayBonusA() 
    {
        try {
			double[] result = HolidayBonus.calculateHolidayBonus(dataset1);
			assertEquals(17000.0, result[0], .001);
			assertEquals(7000.0, result[1], .001);
			assertEquals(12000.0, result[2], .001);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}   
    }

    @Test
    void testCalculateHolidayBonusB() 
    {
        try {
			double[] result = HolidayBonus.calculateHolidayBonus(dataset2);
			assertEquals(8000.0, result[0], .001);
			assertEquals(4000.0, result[1], .001);
			assertEquals(12000.0, result[2], .001);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}   
    }

    @Test
    void testCalculateHolidayBonusC() 
    {
        try {
			double[] result = HolidayBonus.calculateHolidayBonus(dataset3);
			assertEquals(16000.0, result[0], .001);
			assertEquals(5000.0, result[1], .001);
			assertEquals(10000.0, result[2], .001);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}   
    }

    @Test
    void testCalculateTotalHolidayBonus() 
    {
		assertEquals(67000.0, HolidayBonus.calculateTotalHolidayBonus(dataset1), .001);
    }
}
